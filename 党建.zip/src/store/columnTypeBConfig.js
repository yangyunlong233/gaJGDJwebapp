export const columnTypeBState = [
  {
    title: '厅直党建',
    id: '33',
    icon: require('../assets/images/icon_col_title_type_b_01.svg')
  },
  {
    title: '州市党建',
    id: '34',
    icon: require('../assets/images/icon_col_title_type_b_02.svg')
  },
  {
    title: '文明建设',
    id: '35',
    icon: require('../assets/images/icon_col_title_type_b_03.svg')
  },
  {
    title: '时政导读',
    id: '36',
    icon: require('../assets/images/icon_col_title_type_b_04.svg')
  }
]
