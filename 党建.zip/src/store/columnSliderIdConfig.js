export const columnSliderIdState = [31, 32]

export const columnSliderFloatIdState = [31, 32, 33, 34, 35, 36, 37, 42, 43, 44, 45, 46, 47, 48, 49]
