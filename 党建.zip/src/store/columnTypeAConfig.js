export const columnTypeAState = [
  {
    title: '通知通报',
    id: '41',
    icon: require('../assets/images/icon_col_title_type_a_01.svg')
  },
  {
    title: '领导讲话',
    id: '32',
    icon: require('../assets/images/icon_col_title_type_a_02.svg')
  }
]
