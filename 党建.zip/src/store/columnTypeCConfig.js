export const columnTypeCState = [
  {
    title1: '青年工作',
    id1: '37',
    title2: '前卫体协',
    id2: '42'
  },
  {
    title1: '工会之篇',
    id1: '43',
    title2: '',
    id2: ''
  },
  {
    title1: '妇女天地',
    id1: '44',
    title2: '',
    id2: ''
  },
  {
    title1: '党建知识',
    id1: '45',
    title2: '党建研究',
    id2: '46'
  },
  {
    title1: '工作指南',
    id1: '47',
    title2: '他山之石',
    id2: '48'
  },
  {
    title1: '五色长廊',
    id1: '49',
    title2: '警营文学',
    id2: '50'
  }
]
