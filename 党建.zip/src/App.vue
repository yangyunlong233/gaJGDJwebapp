<template>
  <router-view :key="$route.fullPath"/>
</template>

<style lang="scss">
@import './assets/css/normalize.scss';
@import './assets/css/main.scss';
</style>
